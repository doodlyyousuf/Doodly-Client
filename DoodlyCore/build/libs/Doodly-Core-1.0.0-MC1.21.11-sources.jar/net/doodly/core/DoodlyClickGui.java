package net.doodly.core;

import java.util.ArrayList;
import java.util.List;

import me.shedaniel.autoconfig.AutoConfig;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Right-Shift hub. Lists installed Doodly modules and opens their Cloth config.
 * Does not force modules to load — only shows what Fabric reports as present.
 */
public final class DoodlyClickGui extends class_437
{
	private final List<ModuleRow> rows = new ArrayList<>();
	
	private static final class ModuleRow
	{
		final String title;
		final String modId;
		final Class<?> configClass; // null if unknown
		final boolean loaded;
		
		ModuleRow(String title, String modId, Class<?> configClass, boolean loaded)
		{
			this.title = title;
			this.modId = modId;
			this.configClass = configClass;
			this.loaded = loaded;
		}
	}
	
	public DoodlyClickGui()
	{
		super(class_2561.method_43470("Doodly Client"));
	}
	
	@Override
	protected void method_25426()
	{
		rows.clear();
		FabricLoader fl = FabricLoader.getInstance();
		
		rows.add(row("Player Awareness", "doodly_player_awareness",
			"net.doodly.playeresp.PlayerEspConfig"));
		rows.add(row("Chest / Storage ESP", "doodly_utils",
			"net.wimods.chestesp.ChestEspConfig"));
		// chestesp may still use id chestesp on older builds
		if(!rows.get(rows.size() - 1).loaded)
			rows.set(rows.size() - 1, row("Chest / Storage ESP", "chestesp",
				"net.wimods.chestesp.ChestEspConfig"));
		rows.add(row("Base Scan (light + storage)", "doodly_base_scan",
			"net.doodly.basefinder.BaseFinderConfig"));
		rows.add(row("FreeCam", "wi_freecam", null));
		
		int y = 40;
		for(ModuleRow r : rows)
		{
			String label = r.title + (r.loaded ? "  [loaded]" : "  [not installed]");
			int yy = y;
			ModuleRow ref = r;
			method_37063(class_4185.method_46430(class_2561.method_43470(label), b -> openConfig(ref))
				.method_46434(this.field_22789 / 2 - 120, yy, 240, 20)
				.method_46431());
			y += 24;
		}
		
		method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
			.method_46434(this.field_22789 / 2 - 40, this.field_22790 - 28, 80, 20)
			.method_46431());
	}
	
	private ModuleRow row(String title, String modId, String configClassName)
	{
		boolean loaded = FabricLoader.getInstance().isModLoaded(modId);
		Class<?> cfg = null;
		if(loaded && configClassName != null)
		{
			try { cfg = Class.forName(configClassName); }
			catch(ClassNotFoundException ignored) {}
		}
		return new ModuleRow(title, modId, cfg, loaded);
	}
	
	private void openConfig(ModuleRow r)
	{
		if(!r.loaded)
			return;
		if(r.configClass == null)
		{
			// FreeCam / no cloth — nothing to open
			return;
		}
		try
		{
			@SuppressWarnings("unchecked")
			Class<? extends me.shedaniel.autoconfig.ConfigData> c =
				(Class<? extends me.shedaniel.autoconfig.ConfigData>) r.configClass;
			field_22787.method_1507(AutoConfig.getConfigScreen(c, this).get());
		}
		catch(Throwable t)
		{
			// class present but AutoConfig not registered yet
		}
	}
	
	@Override
	public void method_25394(class_332 g, int mouseX, int mouseY, float delta)
	{
		method_25420(g, mouseX, mouseY, delta);
		g.method_25300(this.field_22793, "Doodly Client — modules", this.field_22789 / 2, 15, 0xFFFFFF);
		g.method_25300(this.field_22793, "Right Shift toggles this menu", this.field_22789 / 2, 28, 0xAAAAAA);
		super.method_25394(g, mouseX, mouseY, delta);
	}
	
	@Override
	public boolean method_25421()
	{
		return false;
	}
}
