package net.doodly.core;

import org.lwjgl.glfw.GLFW;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class DoodlyCoreClient implements ClientModInitializer
{
	private class_304 openGui;
	
	@Override
	public void onInitializeClient()
	{
		class_304.class_11900 cat = class_304.class_11900.method_74698(
			class_2960.method_60655("doodly", "core"));
		// Right Shift default — classic client bind
		openGui = KeyBindingHelper.registerKeyBinding(new class_304(
			"key.doodly.open_gui", class_3675.class_307.field_1668,
			GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
		
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while(openGui.method_1436())
			{
				class_310 mc = class_310.method_1551();
				if(mc.field_1755 instanceof DoodlyClickGui)
					mc.method_1507(null);
				else
					mc.method_1507(new DoodlyClickGui());
			}
		});
	}
}
